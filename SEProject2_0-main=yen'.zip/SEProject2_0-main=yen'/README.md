# SDProject
Project of our group for KTU Software Development course
