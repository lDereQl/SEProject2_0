import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Payments = () => {
  return (
    <View>
      <Text>Payments</Text>
    </View>
  )
}

export default Payments

const styles = StyleSheet.create({})