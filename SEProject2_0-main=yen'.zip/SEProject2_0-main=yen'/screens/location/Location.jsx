import { View, Text } from 'react-native'
import React from 'react'

const Location = () => {
  return (
    <View>
      <Text>Location</Text>
    </View>
  )
}

export default Location