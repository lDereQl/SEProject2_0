import { View, Text } from 'react-native'
import React from 'react'

const Payment = () => {
  return (
    <View>
      <Text>Payment</Text>
    </View>
  )
}

export default Payment