import { View, Text } from 'react-native'
import React from 'react'

const ConfirmPayment = () => {
  return (
    <View>
      <Text>ConfirmPayment</Text>
    </View>
  )
}

export default ConfirmPayment