import { View, Text } from 'react-native'
import React from 'react'

const Card = () => {
  return (
    <View>
      <Text>Card</Text>
    </View>
  )
}

export default Card