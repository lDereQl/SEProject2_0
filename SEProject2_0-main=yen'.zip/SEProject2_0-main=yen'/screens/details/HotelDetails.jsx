import { View, Text } from 'react-native'
import React from 'react'

const HotelDetails = () => {
  return (
    <View>
      <Text>HotelDetails</Text>
    </View>
  )
}

export default HotelDetails