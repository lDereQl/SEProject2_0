import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const HotelSearch = () => {
  return (
    <View>
      <Text>HotelSearch</Text>
    </View>
  )
}

export default HotelSearch

const styles = StyleSheet.create({})